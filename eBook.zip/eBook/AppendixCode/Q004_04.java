//3456789012345678901234567890123456789
class Q004_04{
  public static void main(
                        String args[]){
    int[] a1 = new int[1];
    float[] a2 = new float[1];
    boolean[] a3 = new boolean[1];
    String[] a4 = new String[1];

    System.out.print(a1[0] + " " +
                     a2[0] + " " +
                     a3[0] + " " +
                     a4[0] + '\n');    
  }//end main()
}//end class definition