//3456789012345678901234567890123456789

//File Q69.java
class Q69{
  public static void main(
                        String args[]){
    char x = 65;
    char y;
    y = (char)(2*x);
    System.out.println(y);
  }//end main()
}//end class definition