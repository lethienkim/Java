//3456789012345678901234567890123456789

//File Q65.java
class Q65{
   public static void main(
                        String args[]){
     int x = 1;
     int y = ~x + 1;
     System.out.println(x + " " + y);
   }//end main()
 }//end class definition