//3456789012345678901234567890123456789
class Q004_05{
  public static void main(
                        String args[]){
    char[] a1 = new char[1];
    System.out.println((int)a1[0] + " "
                         + (int)'0' + " "
                         + (int)'1');    
  }//end main()
}//end class definition