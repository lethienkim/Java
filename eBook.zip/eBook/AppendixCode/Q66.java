//3456789012345678901234567890123456789

//File Q66.java
class Q66{
  public static void main(
                        String args[]){
    if(!(3 < 4))
      System.out.println("true");
    else
      System.out.println("false");
  }//end main()
}//end class definition