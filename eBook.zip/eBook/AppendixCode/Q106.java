//3456789012345678901234567890123456789

class Q106{
  public static void main(
                        String args[]){
    try{
      byte x = 1;
      boolean y = false;
      System.out.println(
                       (boolean)x & y);
    }catch(Exception e){
      System.out.println(
                   "Exception Thrown");
    }//end catch
  }//end main()
}//end class definition