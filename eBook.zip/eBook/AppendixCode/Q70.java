//3456789012345678901234567890123456789

//File Q70.java
class Q70{
  public static void main(
                        String args[]){
      System.out.println(3/0);
  }//end main()
}//end class definition