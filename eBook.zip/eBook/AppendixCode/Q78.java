//3456789012345678901234567890123456789

class Q78{
  public static void main(
                        String args[]){
    try{
      int x = 64;
      int y = 0;
      System.out.println(x%y);
    }catch(Exception e){
      System.out.println("Exception");
    }//end catch
  }//end main()
}//end class definition