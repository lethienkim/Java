//3456789012345678901234567890123456789

//File Q68.java
class Q68{
  public static void main(
                        String args[]){
    byte x;
    short y = 128;
    x = y;
    System.out.println(x + " " + y);
  }//end main()
}//end class definition