//3456789012345678901234567890123456789

class Q80{
  public static void main(
                        String args[]){
    try{
      byte x = 64;
      byte y = 64;
      System.out.println(x + y);
    }catch(Exception e){
      System.out.println("Exception");
    }//end catch
  }//end main()
}//end class definition