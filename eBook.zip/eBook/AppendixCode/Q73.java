//3456789012345678901234567890123456789

//File Q73.java
class Q73{
  public static void main(
                        String args[]){
    int x;
    double y = -10.9;
    x = (int)y;
    System.out.print(x + " ");
    y = 10.9;
    x = (int)y;
    System.out.println(x);
  }//end main()
}//end class definition