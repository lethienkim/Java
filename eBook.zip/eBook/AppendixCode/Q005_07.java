//3456789012345678901234567890123456789

//File Q005_07.java
import java.awt.Color;
class Q005_07{
  public static void main(
                        String args[]){
    System.out.println(Color.green);
    
    new Q005_07().aMethod();
  }//end main()
  //---------------------------------//
  
  void aMethod(){
    System.out.println(Color.red);
  }//end aMethod()
  
}//end class definition
