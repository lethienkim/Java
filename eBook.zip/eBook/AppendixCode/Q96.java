//3456789012345678901234567890123456789

import java.awt.*;
class Q96{
  public static void main(
                        String args[]){
    try{
      Button var1 = new Button();
      Class var2 = var1.getClass();
      System.out.println(
                 var1 instanceof var2);
    }catch(Exception e){
      System.out.println(
                   "Exception Thrown");
    }//end catch
  }//end main()
}//end class definition