//3456789012345678901234567890123456789

//File Q67.java
class Q67{
  public static void main(
                        String args[]){
    byte x;
    short y = 128;
    x = (byte)y;
    System.out.println(x + " " + y);
  }//end main()
}//end class definition