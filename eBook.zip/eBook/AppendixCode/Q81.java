//3456789012345678901234567890123456789

class Q81{
  public static void main(
                        String args[]){
    System.out.print(
                  Double.isNaN(3.0%0));
    System.out.print(" ");
    System.out.println(
                  Double.isNaN(3.0/0));
  }//end main()
}//end class definition