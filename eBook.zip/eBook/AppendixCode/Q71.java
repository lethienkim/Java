//3456789012345678901234567890123456789

//File Q71.java
class Q71{
  public static void main(
                        String args[]){
      System.out.println(3.0/0);
  }//end main()
}//end class definition