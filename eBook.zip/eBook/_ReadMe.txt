03/22/20
The zip file for the Ebook uploaded to Bb.

05/25/21
None of the lessons are located on cnx

09/05/21
Continue review at Jd0160 